extends Node
## Main — monta o mundo e liga os sistemas.
##
## Ordem de montagem importa: o mundo primeiro (dá alturas), depois as
## estruturas, depois o jogador, depois o que depende dele. Nenhum sistema
## conhece outro: comunicam pelo Bus e por referências explícitas passadas aqui.

var world: World
var structures: Structures
var fx: Node3D
var npc_root: Node3D
var village: Village
var player: Player
var survival: Survival
var inv: Inventory
var interaction: Interaction
var night: NightDirector
var wildlife: Wildlife
var creature_root: Node3D
var hud: Hud
var menus: Menus
var prologo: Prologo
var debug_view: Node

var _cinema_t := 0.0
var _last_held_item := "__unset__"


func _ready() -> void:
	randomize()
	# A sonda `shot` lê a geometria das instâncias: o espelho tem de estar ligado
	# ANTES de o mundo existir (ver scripts/core/shot_meta.gd).
	var probe_args := OS.get_cmdline_args() + OS.get_cmdline_user_args()
	ShotMeta.mirror = probe_args.has("shot")
	_build_world()
	_build_player()
	_build_systems()
	_build_ambient()
	_build_ui()
	_starter_kit()
	_sync_held_item()
	# o mundo à volta do spawn começa logo a existir
	world.set_target(player.global_position)
	world._update_chunks(Vector2i(int(floor(player.global_position.x / Chunk.SIZE)),
		int(floor(player.global_position.z / Chunk.SIZE))), world.radius())
	_build_debug_view()
	print("BLESSED pronto. seed=", Game.world_seed)
	# carimbo de build + renderer efectivo: para saber, olhando para o ecrã ou
	# para a consola do browser, EXACTAMENTE que código está a correr.
	var stamp := ""
	if FileAccess.file_exists("res://build_info"):
		stamp = str(FileAccess.get_file_as_string("res://build_info")).strip_edges()
	if stamp == "":
		stamp = "dev"
	print("BUILD ", stamp)
	print("RENDERER ", str(ProjectSettings.get_setting_with_override(
		"rendering/renderer/rendering_method")), " | OS ", OS.get_name())
	if hud != null:
		hud.set_build(stamp)
	var all_args := OS.get_cmdline_args() + OS.get_cmdline_user_args()

	# sondas de desenvolvimento: `-- selftest`, `-- diag`, …
	# (fora do .pck; servem para medir o jogo a sério, não para jogar)
	for arg in all_args:
		var s_arg := str(arg)
		if s_arg in ["selftest", "diag", "shot", "labtest", "labscene", "gpushot", "labshot", "perf"]:
			_start_probe(s_arg)
			break


## F1/F3/F6/F7/F8/F9 — isolar problemas de renderização a jogar.
func _build_debug_view() -> void:
	debug_view = Node.new()
	debug_view.set_script(load("res://scripts/ui/debug_view.gd"))
	# setup ANTES de add_child: o add_child dispara _ready() imediatamente,
	# e o _ready() precisa de `main` para chegar à árvore.
	debug_view.call("setup", self)
	add_child(debug_view)


## Arranca uma sonda de desenvolvimento (tests/<nome>.gd).
func _start_probe(which: String) -> void:
	var path := "res://tests/%s.gd" % which
	if not ResourceLoader.exists(path):
		print("SELFTEST_FAIL: %s em falta" % path)
		get_tree().quit(1)
		return
	var st: Node = load(path).new()
	st.call("setup", self)
	add_child.call_deferred(st)


## Instancia uma cena editavel (.tscn) se existir; senao usa o fallback em codigo.
## E assim que o jogo deixa de ser so-codigo: cada sistema pode virar uma cena que
## editas no Godot (nodes). Aditivo: sem a cena, comporta-se exatamente como antes.
func _sys(scene_path: String, fallback: Callable) -> Node:
	if ResourceLoader.exists(scene_path):
		var packed = load(scene_path)
		if packed != null:
			var inst = packed.instantiate()
			if inst != null:
				return inst
	return fallback.call()


func _fx_fallback() -> Node:
	var n := Node3D.new()
	n.set_script(load("res://scripts/world/fx.gd"))
	return n


func _build_world() -> void:
	world = _sys("res://scenes/world.tscn", func(): return World.new()) as World
	add_child(world)

	structures = _sys("res://scenes/structures.tscn", func(): return Structures.new()) as Structures
	structures.species = world.species
	structures.mats = world.mats
	add_child(structures)
	structures.setup(world.species, world.mats)

	fx = _sys("res://scenes/fx.tscn", _fx_fallback) as Node3D
	add_child(fx)

	npc_root = Node3D.new()
	npc_root.name = "Npcs"
	add_child(npc_root)

	village = _sys("res://scenes/village.tscn", func(): return Village.new()) as Village
	village.world = world
	village.structures = structures
	village.npc_root = npc_root
	village.species = world.species
	village.mats = world.mats
	add_child(village)
	village.build()

	# ao carregar um jogo com outra semente, o mundo recria terrain/species;
	# re-liga as referências em cache para não ficarem a apontar para o gerador antigo
	Bus.world_reseeded.connect(func():
		structures.species = world.species
		village.species = world.species)


## Onde se nasce.
##
## A aldeia é a referência visual do mundo, por isso nasce-se a ~20-32 m do
## centro: perto o bastante para ver as cabanas, longe o bastante para não
## ficar dentro do anel das fogueiras (o NightDirector não gera criaturas a
## menos de 10 m de uma luz, e nascer encostado a uma tornava a primeira noite
## impossível de avaliar). Antes o spawn saía à volta da ORIGEM, a ~96 m das
## casas — não se via rigorosamente nada.
func _pick_spawn() -> Vector3:
	var ter: Terrain = world.terrain
	var vc: Vector2 = ter.village_center()
	var lit: Array = structures.lit_positions()
	var fallback := ter.find_spawn(vc, 24.0)
	for rr in [20.0, 26.0, 32.0]:
		var ring: float = float(rr)
		for i in 32:
			var a := float(i) / 32.0 * TAU
			var x: float = vc.x + cos(a) * ring
			var z: float = vc.y + sin(a) * ring
			if ter.slope(x, z) >= 0.35 or ter.is_water(x, z):
				continue
			var near_fire := false
			for lp in lit:
				if (lp as Vector3).distance_to(Vector3(x, 0, z)) < 14.0:
					near_fire = true
					break
			if near_fire:
				continue
			return Vector3(x, ter.height(x, z), z)
	return fallback


func _build_player() -> void:
	player = _sys("res://scenes/player.tscn", func(): return Player.new()) as Player
	# VoxelLodTerrain cria a malha e a colisão de forma assíncrona. Mantém o
	# CharacterBody suspenso até a zona de spawn estar mesclada; caso contrário,
	# a gravidade começa primeiro e o jogador atravessa o terreno ainda vazio.
	var wait_for_voxel_collision := world.use_voxel_terrain
	if wait_for_voxel_collision:
		player.enabled = false
	world.add_child(player)
	# Grupos: há sistemas que precisam do jogador/supervivência sem terem uma
	# referência direta (ex.: a árvore que cai e magoa quem está debaixo dela).
	if not player.is_in_group("player"):
		player.add_to_group("player")
	var spawn := _pick_spawn()
	# Os chunks do mundo só nascem depois disto (em `world._update_chunks`), por
	# isso a vegetação já sabe que ali não se planta nada.
	world.set_spawn_clear(spawn)
	player.global_position = spawn + Vector3(0, 1.0, 0)
	# VoxelLodTerrain só cria blocos quando há um VoxelViewer na árvore.
	# O viewer acompanha o personagem e pede malha e colisão ao redor dele.
	world.attach_voxel_viewer(player)
	if wait_for_voxel_collision:
		call_deferred("_wait_for_spawn_collision", spawn)

	survival = Survival.new()
	player.add_child(survival)
	if not survival.is_in_group("survival"):
		survival.add_to_group("survival")


func _wait_for_spawn_collision(spawn: Vector3) -> void:
	var warning_at := Time.get_ticks_msec() + 15000
	var warned := false
	while is_instance_valid(player) and is_instance_valid(world):
		if world.voxel_collision_ready_at(spawn):
			# Deixa a física observar a forma que acabou de ser registada antes de
			# soltar o jogador; a posição final usa a mesma fonte de altura do SDF.
			await get_tree().physics_frame
			if not is_instance_valid(player):
				return
			player.teleport(Vector3(spawn.x,
				world.ground_height(spawn.x, spawn.z) + 1.0, spawn.z))
			player.enabled = true
			print("WORLD spawn grounded on voxel collision")
			return
		if not warned and Time.get_ticks_msec() >= warning_at \
				and DisplayServer.get_name() != "headless":
			push_warning("A aguardar a colisão voxel da zona inicial antes de ativar o jogador")
			warned = true
		await get_tree().process_frame


func _build_systems() -> void:
	inv = Inventory.new()
	add_child(inv)

	player.survival = survival

	interaction = Interaction.new()
	interaction.player = player
	interaction.world = world
	interaction.survival = survival
	interaction.inv = inv
	interaction.structures = structures
	interaction.fx = fx
	interaction.npc_root = npc_root
	add_child(interaction)

	creature_root = Node3D.new()
	creature_root.name = "Creatures"
	add_child(creature_root)

	night = NightDirector.new()
	night.player = player
	night.world = world
	night.structures = structures
	night.survival = survival
	night.root = creature_root
	add_child(night)

	# caça diurna: os animais partilham o nó das criaturas (é tudo bicho em cena)
	wildlife = Wildlife.new()
	wildlife.player = player
	wildlife.world = world
	wildlife.inv = inv
	wildlife.root = creature_root
	add_child(wildlife)


func _build_ambient() -> void:
	var amb := _sys("res://scenes/ambient_fx.tscn", _ambient_fallback)
	amb.set("player", player)
	add_child(amb)


func _ambient_fallback() -> Node:
	var n := Node3D.new()
	n.set_script(load("res://scripts/world/ambient_fx.gd"))
	return n


func _build_ui() -> void:
	hud = _sys("res://scenes/hud.tscn", func(): return Hud.new()) as Hud
	hud.inv = inv
	hud.interaction = interaction
	hud.survival = survival
	hud.player = player
	add_child(hud)

	menus = Menus.new()
	menus.inv = inv
	menus.interaction = interaction
	menus.survival = survival
	menus.player = player
	add_child(menus)
	# a interação abre a interface DA estação apontada (bancada, fogueira)
	if interaction != null:
		interaction.menus = menus

	prologo = Prologo.new()
	add_child(prologo)

	Bus.time_advanced.connect(_on_time)
	Bus.locale_changed.connect(_on_locale)
	Sfx.set_music_phase(Game.current_phase())
	_on_time(Game.hour, Game.day)


func _starter_kit() -> void:
	inv.add("torch", 1)
	inv.add("mushroom", 2)


# ══════════════════════════════════════════════════════════════════════════
func _process(delta: float) -> void:
	if not Game.started:
		_cinema(delta)
		return
	world.set_target(player.global_position)
	_sync_held_item()
	_apply_player_state()
	_sense_light()
	_hotbar_input()


func _apply_player_state() -> void:
	player.speed_multiplier = survival.speed_multiplier()
	player.stamina_drain_multiplier = 1.0 if survival.energy > 25.0 else 1.5


func _sense_light() -> void:
	var l := Game.daylight()
	# tocha na mão
	if inv.hotbar_id() == "torch":
		l = maxf(l, 0.55)
	# fogueiras acesas
	for p in structures.lit_positions():
		var d: float = (p as Vector3).distance_to(player.global_position)
		if d < 12.0:
			l = maxf(l, clampf(1.0 - d / 12.0, 0.0, 1.0) * 0.95)
	survival.light_level = clampf(l, 0.0, 1.0)
	survival.near_fire = not structures.lit_positions().is_empty() \
		and _min_light_distance() < 7.0
	survival.sheltered = structures.has_shelter(player.global_position, 5.0)
	survival.companion_near = _companion_near()


func _min_light_distance() -> float:
	var best := 1e18
	for p in structures.lit_positions():
		best = minf(best, (p as Vector3).distance_to(player.global_position))
	return best


func _companion_near() -> bool:
	for c in npc_root.get_children():
		if c is Node3D and (c as Node3D).global_position.distance_to(player.global_position) < 9.0:
			return true
	return false


func _hotbar_input() -> void:
	for i in 9:
		if Input.is_action_just_pressed("hotbar_%d" % (i + 1)):
			inv.select(i)
	_sync_held_item()


func _sync_held_item() -> void:
	if player == null or player.hands == null or inv == null:
		return
	var id := inv.hotbar_id()
	if id == _last_held_item:
		return
	_last_held_item = id
	if player.hands.has_method("set_item"):
		player.hands.call("set_item", id)


func _unhandled_input(event: InputEvent) -> void:
	if not Game.started:
		return
	if event.is_action_pressed("save"):
		Game.save_game()
	elif event.is_action_pressed("drop"):
		var id := inv.hotbar_id()
		if id != "":
			# Larga no mundo com peso, ressalto curto e recolha por contacto.
			var di := load("res://scripts/world/dropped_item.gd").new() as RigidBody3D
			if di == null:
				return
			inv.remove(id, 1)
			di.set("item_id", id)
			di.set("amount", 1)
			di.set("inv", inv)
			di.set("player_ref", player)
			di.set("launch_direction", -player.global_transform.basis.z)
			di.position = player.global_position - player.global_transform.basis.z * 1.3 \
				+ Vector3(0.0, 0.65, 0.0)
			add_child(di)
	elif event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			inv.next_slot(-1)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			inv.next_slot(1)
	elif event is InputEventKey and event.pressed and event.keycode == KEY_R:
		if survival.blessing >= 35.0:
			survival.flare_blessing()
			_push_back_creatures()


func _push_back_creatures() -> void:
	for c in get_tree().get_nodes_in_group("creatures"):
		if is_instance_valid(c):
			(c as Creature).hurt(18.0)


func _on_time(hour: float, day: int) -> void:
	if world != null:
		world.update_time(hour, Game.daylight(), Game.current_phase())
	Sfx.set_music_phase(Game.current_phase())


func _on_locale(_code: String) -> void:
	if hud:
		hud.refresh_locale()


# ══════════════════════════════════════════════════════════════════════════
#  Câmar cinematográfica do prólogo: uma volta lenta sobre o vale.
# ══════════════════════════════════════════════════════════════════════════
func _cinema(delta: float) -> void:
	_cinema_t += delta
	var c := world.terrain.village_center()
	var a := _cinema_t * 0.07
	var r := 26.0 + sin(_cinema_t * 0.11) * 6.0
	var p := Vector3(c.x + cos(a) * r, 0, c.y + sin(a) * r)
	p.y = world.ground_height(p.x, p.z) + 4.5 + sin(_cinema_t * 0.2) * 1.2
	player.global_position = p
	player.target_yaw = atan2(-(c.x - p.x), -(c.y - p.z))
	player.target_pitch = -0.12
	player.yaw = lerpf(player.yaw, player.target_yaw, 1.0 - exp(-1.5 * delta))
	player.pitch = lerpf(player.pitch, player.target_pitch, 1.0 - exp(-1.5 * delta))
	player.rotation.y = player.yaw
	player.cam_pivot.rotation.x = player.pitch
	world.set_target(p)
	world.update_time(Game.hour, Game.daylight(), Game.current_phase())
